function fun1()
{
alert("Welcome to MY PAGE");
}
function printMsg()

{
	document.write("Saurabh ");
}
function  square()
{
	var a=prompt(" enter text");
	var b=confirm("Should i dislay it");
	if(b ==true){
		alert("text is :" + (a) );
	}
	
}